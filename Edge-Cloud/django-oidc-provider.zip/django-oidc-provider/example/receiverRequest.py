from socket import *

# EDGE_IP = '127.0.0.1'
# EDGE_IP = '192.168.0.108'
EDGE_IP = '192.168.0.111'
vUser_CLIENT_PORT_IMSI = 12000  # this port is the vUser client port for forwarding IMSI to home edge MME
vUser_CLIENT_PORT_RES = 37000  # this port is the vUser client port for forwarding RES to home edge MME

vUser_IP = '127.0.0.1'
vUser_SERVER_PORT = 11000  # this port is the vUser server port for receiving IMSI from OIDC client

with socket(AF_INET, SOCK_STREAM) as vUser_serverSocket:
    vUser_serverSocket.bind((vUser_IP, vUser_SERVER_PORT))
    vUser_serverSocket.listen()

    # Waiting for connection from Fog/OIDC client
    while True:
        print('Waiting to receive IMSI from fog...')
        conn, addr = vUser_serverSocket.accept()
        with conn:
            print('Connected by', addr)
            while True:
                data = conn.recv(20000)
                if not data:
                    break
                else:
                    data = data.decode('utf-8')
                    print('Received data: ' + data)
                    # Connect to edge MME
                    with socket(AF_INET, SOCK_STREAM) as vUser_clientSocket:
                        if len(data) == 15 and data.isdigit():
                            vUser_clientSocket.connect((EDGE_IP, vUser_CLIENT_PORT_IMSI))
                        else:
                            vUser_clientSocket.connect((EDGE_IP, vUser_CLIENT_PORT_RES))
                        vUser_clientSocket.sendall(bytes(data, 'utf-8'))
                        vUser_clientSocket.close()
