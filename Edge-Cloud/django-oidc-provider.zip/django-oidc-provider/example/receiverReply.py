import ast
import json
from socket import *
import os
import string
import random
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'app.settings')
django.setup()

from django.contrib.auth.models import User


def random_char(y):
    return ''.join(random.choice(string.ascii_letters) for x in range(y))


def deleteUser():
    myuserFile = open('myUser.txt', 'r')
    line = myuserFile.readline()
    line = line.split(' ')
    if User.objects.filter(username=line[0]).exists():
        user = User.objects.get(username=line[0])
        user.delete()
    myuserFile.close()


# vUser_IP = '192.168.0.103'
vUser_IP = '192.168.0.104'
# vUser_IP = '192.168.0.107'
# vUser_IP = '127.0.0.1'
vUser_SERVER_PORT = 21000  # this is the server port for receiving auth Challenge from home edge MME

FOG_IP = '127.0.0.1'
vUser_CLIENT_PORT = 20000  # this is the client port for forwarding auth Challenge to fog

with socket(AF_INET, SOCK_STREAM) as vUser_serverSocket:
    vUser_serverSocket.bind((vUser_IP, vUser_SERVER_PORT))
    vUser_serverSocket.listen()
    while True:
        print('Waiting for connection from home edge MME...')
        conn, addr = vUser_serverSocket.accept()
        with conn:
            print('Connected to home edge MME by', addr)
            while True:
                authChallenge = conn.recv(20000)
                if not authChallenge:
                    break
                else:
                    authChallenge = authChallenge.decode('utf-8')
                    print("Received data: ", authChallenge)
                    if authChallenge == '200 OK':
                        deleteUser()
                        userName = random_char(3)
                        email = random_char(3) + "@" + random_char(5) + ".com"
                        password = random.randint(10000, 20000)
                        newUser = User.objects.create_superuser(userName, email, password)
                        newUser.save()
                        myuserFile = open('myUser.txt', 'w')
                        myuserFile.write(userName + ' ' + email + ' ' + str(password))
                        myuserFile.close()
                    else:
                        authChallenge = ast.literal_eval(authChallenge)
                        authChallenge = json.dumps(authChallenge)
                    with socket(AF_INET, SOCK_STREAM) as vUser_clientSocket:
                        vUser_clientSocket.connect((FOG_IP, vUser_CLIENT_PORT))
                        vUser_clientSocket.sendall(bytes(authChallenge, 'utf-8'))
                        vUser_clientSocket.close()
