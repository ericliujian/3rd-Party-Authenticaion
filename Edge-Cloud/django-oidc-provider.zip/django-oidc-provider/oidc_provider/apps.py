from django.apps import AppConfig


class OIDCProviderConfig(AppConfig):

    name = 'oidc_provider'
    verbose_name = u'OpenID Connect Provider'
