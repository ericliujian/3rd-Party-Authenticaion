
default_app_config = 'oidc_provider.apps.OIDCProviderConfig'
